package com.example.assignmentweek9;

public class Shape {

    public double x, y, r, area, circumference;

}
