package com.example.mobileappdevelopment;


public class Car {
    public String model;
    public String battery;
    public float mx_speed;
    public String image;

    public Car(String model, String battery, float mx_speed, String image) {
        this.model = model;
        this.battery = battery;
        this.mx_speed = mx_speed;
        this.image = image;
    }


}
